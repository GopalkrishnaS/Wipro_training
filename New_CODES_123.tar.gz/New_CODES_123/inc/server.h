/*server.h*/
// ... existing includes ...
//#include "user_db.h" // Add this include

// ... rest of your server.h ...

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/shm.h>
#include "user_db.h" // Add this include

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

typedef struct {
    int client_id;
    char username[50];
    int active; // 1 = registered, 0 = not registered
} ClientInfo;



