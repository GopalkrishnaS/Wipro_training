/*user_db.h*/
#ifndef USER_DB_H
#define USER_DB_H

#define USER_DB_FILE "user_db.txt"
#define MAX_USERNAME_LEN 50
#define MAX_PASSWORD_LEN 50

int register_user(const char *username, const char *password);
int login_user(const char *username, const char *password);

#endif
