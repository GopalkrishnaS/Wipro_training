#include "user_db.h"
#include <stdio.h>
#include <string.h>

// Register a new user. Returns 1 if successful, 0 if username exists.
int register_user(const char *username, const char *password) {
	FILE *fp = fopen(USER_DB_FILE, "a+");
	if (!fp) return 0;

	char line[256];
	while (fgets(line, sizeof(line), fp)) {
		char file_user[MAX_USERNAME_LEN];
		sscanf(line, "%s", file_user);
		if (strcmp(file_user, username) == 0) {
			fclose(fp);
			return 0; // Username exists
		}
	}
	fprintf(fp, "%s %s\n", username, password);
	fclose(fp);
	return 1;
}

// Login user. Returns 1 if successful, 0 otherwise.
int login_user(const char *username, const char *password) {
	FILE *fp = fopen(USER_DB_FILE, "r");
	if (!fp) return 0;

	char file_user[MAX_USERNAME_LEN], file_pass[MAX_PASSWORD_LEN];
	while (fscanf(fp, "%s %s", file_user, file_pass) != EOF) {
		if (strcmp(username, file_user) == 0 && strcmp(password, file_pass) == 0) {
			fclose(fp);
			return 1; // Success
		}
	}
	fclose(fp);
	return 0;
}
