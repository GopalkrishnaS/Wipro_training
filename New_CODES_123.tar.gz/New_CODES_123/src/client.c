// ... All your existing includes

#include "../inc/client.h"	//This is necessary headerfile for this code 

int *client_count;

#define FATAL "FATAL"
#define INFO "INFO"
#define WARNING "WARNING"

void log_message(const char *level, const char *message) {
	time_t now = time(NULL);
	char *timestamp = ctime(&now);
	timestamp[strcspn(timestamp, "\n")] = 0;
	printf("[%s] [%s]: %s\n", timestamp, level, message);
}

void *receive_messages(void *socket_desc) {
	int server_socket = *(int *)socket_desc;
	char buffer[BUFFER_SIZE];

	while (1) {
		memset(buffer, 0, BUFFER_SIZE);
		int bytes_received = recv(server_socket, buffer, BUFFER_SIZE, 0);
		if (bytes_received > 0) {
			printf("\r%s\n", buffer); // [USERNAME FEATURE] Will show 'username: message'
			printf("\nEnter message> ");
			fflush(stdout);
		}
	}
	return NULL;
}

void store_shared_memory(int *shared_memory) {
	client_count = shared_memory + MAX_CLIENTS;
}

int main() {
	printf("\nStarting client application.\n");
	printf("=======================================\n");
	printf("		Welcome		       \n");
	printf("=======================================\n");	
	key_t key = ftok("shmfil", 65);
	int shmid = shmget(key, (MAX_CLIENTS + 1) * sizeof(int), 0666 | IPC_CREAT);
	if (shmid == -1) {
		perror("Shared memory creation failed.");
		exit(1);
	}

	int *shared_memory = (int *)shmat(shmid, NULL, 0);
	if (shared_memory == (void *)-1) {
		perror("Shared memory attach failed.");
		exit(1);
	}

	store_shared_memory(shared_memory);

	int client_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (client_socket == -1) {
		perror("Socket creation failed.");
		exit(1);
	}

	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

	if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
		perror("\nConnection to server failed.");
		exit(1);
	}

	printf("Connected to server.\n");

	while (1) {
		int choice;
		char username[50], password[50];

		printf("\nEnter a Choice:\n 1. Register\n 2. Login\n 3. Exit\n");
		scanf(" %d", &choice);
		getchar();

		switch (choice) {
			case 1:
				printf("Enter new username: ");
				fgets(username, 50, stdin);
				username[strcspn(username, "\n")] = 0;
				printf("Enter new password: ");
				fgets(password, 50, stdin);
				password[strcspn(password, "\n")] = 0;

				char reg_message[BUFFER_SIZE];
				snprintf(reg_message, BUFFER_SIZE, "REGISTER-> %s %s", username, password);
				send(client_socket, reg_message, strlen(reg_message), 0);

				char reg_resp[BUFFER_SIZE];
				recv(client_socket, reg_resp, BUFFER_SIZE, 0);
				if (strncmp(reg_resp, "REGISTER_SUCCESS", 16) == 0) {
					printf("Registration successful...\n");
				} else {
					printf("Registration failed (username may already exist)...\n");
				}
				continue;

			case 2:
				printf("Enter username: ");
				fgets(username, 50, stdin);
				username[strcspn(username, "\n")] = 0;
				printf("Enter password: ");
				fgets(password, 50, stdin);
				password[strcspn(password, "\n")] = 0;

				char login_message[BUFFER_SIZE];
				snprintf(login_message, BUFFER_SIZE, "LOGIN-> %s %s", username, password);
				send(client_socket, login_message, strlen(login_message), 0);

				char login_resp[BUFFER_SIZE];
				recv(client_socket, login_resp, BUFFER_SIZE, 0);
				if (strncmp(login_resp, "LOGIN_SUCCESS", 13) == 0) {
					printf("Login Successful...\n");
				} else {
					printf("Login failed. Please try again.\n");
					continue;
				}
				pthread_t receive_thread;
				pthread_create(&receive_thread, NULL, receive_messages, (void *)&client_socket);

				char message[BUFFER_SIZE];
				while (1) {
					printf("\nEnter message> ");
					fgets(message, BUFFER_SIZE, stdin);
					message[strcspn(message, "\n")] = 0;

					send(client_socket, message, strlen(message), 0);
				}

				break;

			case 3:
				printf("Exiting client.\n");
				close(client_socket);
				shmdt(shared_memory);
				exit(0);

			default:
				printf("Invalid choice. Try again.");
				continue;
		}
		close(client_socket);
		shmdt(shared_memory);
		printf("Client disconnected.\n");
		return 0;
	}
}
