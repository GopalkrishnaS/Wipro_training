// ... All your existing includes

#include "../inc/user_db.h" // Add this line

// ... All your existing code ...

#include "../inc/server.h"
#include <signal.h>

int *clients;		//Pointer to an array of client identifiers (e.g., socket file descriptors) 
int *client_count;	// This may be used to track how many clients are currently active.
int server_fd; 		// connections from clients and to communicate with them.
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;	// connections from clients and to communicate with them.

FILE *log_file;	/*This file can be used to record events for debugging or monitoring purposes, allowing the server 
		  to maintain a history of its operations.*/	

// [USERNAME FEATURE] Add array for usernames
char client_usernames[MAX_CLIENTS][MAX_USERNAME_LEN];

// Signal handler to close the server gracefully
void handle_sigint(int sig) {
	printf("\nShutting down server...\n");
	close(server_fd); 
	if (log_file) fclose(log_file);
	exit(0); 
}

// [LOGGING FIX] Add timestamp and log to console and file
void log_message(const char *level, const char *message) {
	if (log_file) {
		time_t now = time(NULL);
		char *timestamp = ctime(&now);
		timestamp[strcspn(timestamp, "\n")] = 0;
		fprintf(log_file, "[%s] [%s]: %s\n", timestamp, level, message);
		fflush(log_file);
	}
	printf("[%s]: %s\n", level, message);
}

// Function to store shared memory pointers for client management.
void store_shared_memory(int *shared_memory) {
	clients = shared_memory;
	client_count = shared_memory + MAX_CLIENTS;
	*client_count = 0;
	// [USERNAME FEATURE] Clear usernames
	for (int i = 0; i < MAX_CLIENTS; i++) {
		client_usernames[i][0] = '\0';
	}
}

// [USERNAME FEATURE] Broadcast with username
void broadcast_message(char *message, int sender_socket) {
	pthread_mutex_lock(&lock);

	// Find sender's username
	char sender_username[MAX_USERNAME_LEN] = "Unknown";
	for (int i = 0; i < *client_count; i++) {
		if (clients[i] == sender_socket) {
			strncpy(sender_username, client_usernames[i], MAX_USERNAME_LEN);
			sender_username[MAX_USERNAME_LEN-1] = '\0';
			break;
		}
	}

	// Prepend username to message
	char msg_with_username[BUFFER_SIZE + MAX_USERNAME_LEN + 4];
	snprintf(msg_with_username, sizeof(msg_with_username), "%s: %s", sender_username, message);

	for (int i = 0; i < *client_count; i++) {
		if (clients[i] != sender_socket) {
			send(clients[i], msg_with_username, strlen(msg_with_username), 0);
		}
	}
	pthread_mutex_unlock(&lock);
}

// Update handle_client to support registration/login
void *handle_client(void *socket_desc) {
	int client_socket = *(int *)socket_desc;
	char buffer[BUFFER_SIZE];

	while (1) {
		memset(buffer, 0, BUFFER_SIZE);
		int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
		if (bytes_received <= 0) {
			pthread_mutex_lock(&lock);
			for (int i = 0; i < *client_count; i++) {
				if (clients[i] == client_socket) {
					clients[i] = clients[*client_count - 1];
					strcpy(client_usernames[i], client_usernames[*client_count - 1]);
					client_usernames[*client_count - 1][0] = '\0';
					(*client_count)--;
					break;
				}
			}
			pthread_mutex_unlock(&lock);
			close(client_socket);
			log_message("INFO", "Client disconnected");
			break;
		}

		// Check for registration/login commands
		if (strncmp(buffer, "REGISTER->", 10) == 0) {
			char username[MAX_USERNAME_LEN], password[MAX_PASSWORD_LEN];
			sscanf(buffer, "REGISTER-> %s %s", username, password);
			if (register_user(username, password)) {
				send(client_socket, "REGISTER_SUCCESS", strlen("REGISTER_SUCCESS"), 0);
				log_message("INFO", "User registered successfully");
			} else {
				send(client_socket, "REGISTER_FAILED", strlen("REGISTER_FAILED"), 0);
				log_message("WARNING", "Username already exists for registration");
			}
			continue;
		} else if (strncmp(buffer, "LOGIN->", 7) == 0) {
			char username[MAX_USERNAME_LEN], password[MAX_PASSWORD_LEN];
			sscanf(buffer, "LOGIN-> %s %s", username, password);
			if (login_user(username, password)) {
				send(client_socket, "LOGIN_SUCCESS", strlen("LOGIN_SUCCESS"), 0);
				// [USERNAME FEATURE] Store username for this client
				int idx = -1;
				pthread_mutex_lock(&lock);
				for (int i = 0; i < *client_count; i++) {
					if (clients[i] == client_socket) {
						idx = i;
						break;
					}
				}
				if (idx != -1) {
					strncpy(client_usernames[idx], username, MAX_USERNAME_LEN);
					client_usernames[idx][MAX_USERNAME_LEN-1] = '\0';
				}
				pthread_mutex_unlock(&lock);
				log_message("INFO", "User logged in successfully");
			} else {
				send(client_socket, "LOGIN_FAILED", strlen("LOGIN_FAILED"), 0);
				log_message("WARNING", "Login attempt failed");
			}
			continue;
		}

		// [USERNAME FEATURE] Log and print with username
		char sender_username[MAX_USERNAME_LEN] = "Unknown";
		pthread_mutex_lock(&lock);
		for (int i = 0; i < *client_count; i++) {
			if (clients[i] == client_socket) {
				strncpy(sender_username, client_usernames[i], MAX_USERNAME_LEN);
				sender_username[MAX_USERNAME_LEN-1] = '\0';
				break;
			}
		}
		pthread_mutex_unlock(&lock);

		char msg_with_username[BUFFER_SIZE + MAX_USERNAME_LEN + 4];
		snprintf(msg_with_username, sizeof(msg_with_username), "%s: %s", sender_username, buffer);

		printf("Received: %s\n", msg_with_username);
		log_message("INFO", msg_with_username);

		broadcast_message(buffer, client_socket);
	}
	return NULL;
}

// ... rest of your code ...
// Main function: Entry point of the server application.
int main() {
	system("mkdir -p log");
	log_file = fopen("log/server_log.txt", "a");
	log_file = fopen("log/client_log.txt", "a");
	if (!log_file) {
		perror("Failed to open log file");
		exit(1);
	}

	key_t key = ftok("shmfile", 65);
	int shmid = shmget(key, (MAX_CLIENTS + 1) * sizeof(int), 0666 | IPC_CREAT);
	if (shmid == -1) {
		perror("Shared memory creation failed");
		log_message("FATAL", "Shared memory creation failed");
		exit(1);
	}

	int *shared_memory = (int *)shmat(shmid, NULL, 0);
	if (shared_memory == (void *)-1) {
		perror("Shared memory attach failed");
		log_message("FATAL", "Shared memory attach failed");
		exit(1);
	}
	FILE *file = fopen("shared_memory_dump.txt", "w"); // File in your directory
	if (file == NULL) {
		perror("File open failed.");
		log_message("ERROR", "File open failed for shared_memory_dump.txt");
		shmdt(shared_memory);
		exit(1);
	}
	fprintf(file, "Shared memory contents:\n");
	for (int i = 0; i < MAX_CLIENTS + 1; i++) {
		fprintf(file, "shared_memory[%d] = %d\n", i, shared_memory[i]);
	}
	fclose(file);

	store_shared_memory(shared_memory);

	int server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket == -1) {
		perror("Socket creation failed");
		log_message("FATAL", "Socket creation failed");
		exit(1);
	}

	struct sockaddr_in server_addr, client_addr;
	socklen_t client_len = sizeof(client_addr);

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
		perror("Bind failed");
		log_message("FATAL", "Bind failed");
		exit(1);
	}

	if (listen(server_socket, MAX_CLIENTS) < 0) {
		perror("Listen failed");
		log_message("FATAL", "Listen failed");
		exit(1);
	}

	signal(SIGINT, handle_sigint);

	printf("Server listening on port %d\n", PORT);
	log_message("INFO", "Server started");

	while (1) {
		int client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
		if (client_socket < 0) {
			perror("Accept failed");
			log_message("WARNING", "Accept failed");
			continue;
		}

		pthread_mutex_lock(&lock);
		clients[*client_count] = client_socket;
		client_usernames[*client_count][0] = '\0'; // [USERNAME FEATURE]
		(*client_count)++;
		pthread_mutex_unlock(&lock);

		log_message("INFO", "New client connected");

		pthread_t thread;
		pthread_create(&thread, NULL, handle_client, (void *)&client_socket);
	}

	close(server_socket);
	fclose(log_file);
	shmctl(shmid, IPC_RMID, NULL);
	return 0;
}
